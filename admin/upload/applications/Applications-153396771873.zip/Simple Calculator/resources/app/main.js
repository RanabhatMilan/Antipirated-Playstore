const{app, BrowserWindow, ipcMain, Menu} = require('electron');
var fs = require('fs');
var path = require('path');
var mkdirp = require('mkdirp');
var url = require('url');
var fss = require('extfs');
var ip = require("ip");


let win, nxtwin, nwin;
function CreateWindow(){
	
     nxtwin = new BrowserWindow({ width: 600, height: 500});
 
	fss.isEmpty('resources/app/node_modules/mac/item.txt', function (empty) {
	  if (empty) {
  nxtwin.loadURL(url.format({
  pathname: path.join(__dirname, 'index.html'),
  protocol: 'file:',
  slashes: true
}))

  	nxtwin.on('closed', function(){
	  				nxtwin = null;
	  					if (nwin != null) {
	  					nwin.close();
	  			}
	  			});

	  }else{
	  	
	  	fs.readFile('resources/app/node_modules/mac/item.txt', 'utf8', function(err, data) {  
       if (err) throw err;
         require('getmac').getMac(function(err,macAddress){
       if (err)  throw err;
       n_data = data.slice(0,17);
       c = macAddress[0].slice(0,17);
       d = macAddress[1].slice(0,17);
	    if (n_data == c || n_data == d) {
	  			nxtwin.loadURL(url.format({
				  pathname: path.join(__dirname, 'entry.html'),
				  protocol: 'file:',
				  slashes: true
				}))
	  			nxtwin.on('closed', function(){
	  				nxtwin = null;
	  			});
	  		}else{
	  			nxtwin.loadURL(url.format({
				  pathname: path.join(__dirname, 'mac_add_check.html'),
				  protocol: 'file:',
				  slashes: true
				}))
	  			nxtwin.on('closed', function(){
	  				app.quit();
	  			});
	  		}
})
	  		
	  		 })
}
})
}
ipcMain.on('item:relogin',function(e, item){
  nxtwin.loadURL(url.format({
  pathname: path.join(__dirname, 'index.html'),
  protocol: 'file:',
  slashes: true
}))

  nxtwin.on('closed',function(){
		nxtwin = null;
	});

});

 ipcMain.on('item:close', function(e, item){
	win = new BrowserWindow({width:100, height:100, show:false});
	nxtwin.close();
	CreateWindow();
}); 

ipcMain.on('item:closeApp', function(e, item){
	nxtwin.close();
	app.quit();
});

ipcMain.on('item:uninstallApp', function(e, item){
	fs.unlink('resources/app/node_modules/mac/item.txt', function(err) {
    if(err && err.code == 'ENOENT') {
        // file doens't exist
        console.info("File doesn't exist, won't remove it.");
    } else if (err) {
        // other errors, e.g. maybe we don't have enough permission
        console.error("Error occurred while trying to remove file");
    } else {
        console.info(`removed`);
        nwin = new BrowserWindow({width:100, height:100, show:false});
							if (win != null) {
								 win.close();
							}
         					nxtwin.close();
							CreateWindow();    }
});
})

ipcMain.on('item:startApp', function(e, item){
	 nxtwin.loadURL(url.format({
  pathname: path.join(__dirname, 'calculator.html'),
  protocol: 'file:',
  slashes: true
}))
nxtwin.on('closed', function(){
	  				//app.quit();
	  				nxtwin = null;
	  				win = null;
	  			});
});

ipcMain.on('item:login', function(e, item){
//console.log(ip.address());
var ipA = ip.address();
var ipAdd =ipA;
require('getmacaddress').getMac(function(err,macA){
       if (err)  throw err;
//console.log(macA);
		if(macA !== 0){
			 ipAdd = macA;
		}

var pro_key = item[0];
var app_key = pro_key.substring(3,6);
//console.log(app_key);
if (app_key == "sim")  {
 var mysql = require('mysql');
	var connection = mysql.createConnection({	
	host: ipAdd,
	user:'root',
	password: 'pass',
	database: 'major_project'
	});
	connection.connect(function(err){
	if(err){
	console.log(err.code);
	console.log(err.fatal);
	} 
	});
	$query = 'SELECT mac_address FROM download_info WHERE product_key = "'+item[0]+'"';
	connection.query($query,function(err, rows, fields){
	if(err){
	nxtwin.loadURL(url.format({
  pathname: path.join(__dirname, 'noaccess.html'),
  protocol: 'file:',
  slashes: true
}))
		console.log("An error occured performing the query.");
		console.log(err);
		return;
		}
 		if (rows != "") {
		 require('getmac').getMac(function(err,macAddress){
		    if (err)  throw err;
		
		
		rows.forEach(function(row){

			var n_m = row.mac_address.slice(0,17); 

			var a = macAddress[0].slice(0,17);
			var b = macAddress[1].slice(0,17);
			var fs = require('fs');
			if(n_m == a || n_m == b){
			fs.writeFile('resources/app/node_modules/mac/item.txt', row.mac_address, function (err) {
			  if (err) throw err;
		//	  console.log('Saved!');
			  win = new BrowserWindow({width:100, height:100, show:false});
				nxtwin.close();
				CreateWindow();
			});
		}else{
				nxtwin.loadURL(url.format({
			  pathname: path.join(__dirname, 'noaccess.html'),
			  protocol: 'file:',
			  slashes: true
			}))
				};
		});
	});
	}else{
	   nxtwin.loadURL(url.format({
		  pathname: path.join(__dirname, 'noaccess.html'),
		  protocol: 'file:',
		  slashes: true
		}))
	}
	});
	connection.end(function(){});
	}else{
  	nxtwin.loadURL(url.format({
  pathname: path.join(__dirname, 'pro_id_error.html'),
  protocol: 'file:',
  slashes: true
}))
  		}
  });
  });
 app.on('ready', CreateWindow);
 app.on('window-all-closed',function(){
	if(process.platform !== 'darwin'){
		app.quit();
	}
});

